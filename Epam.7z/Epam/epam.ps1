﻿param(
    [parameter(Mandatory=$false, position=0)] [string] $basePath = 'C:\TEMP\Epam\DogsAndCats',
    [parameter(Mandatory=$false, position=1)] [System.Array] $fileMask = @('*.txt','*.log')
)

<#
.SYNOPSIS
    Function to write colored log to the screen and/or plain log to file

.DESCRIPTION
    ...

.PARAMETER msg
    ...

.PARAMETER what
    ...

.EXAMPLE
    ...
#>
function Write-MyLog {
    [CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact="Low")]
    param(
        [parameter(Mandatory=$true, position=0)] [ValidateNotNullOrEmpty()] [string] $msg,
        [parameter(Mandatory=$false, position=1)] [ValidateSet('ok', 'info', 'warning', 'error', 'exception', 'fatal', 'semi')] [string] $what = "info"
    )
    $dat = Get-Date;
    switch($what) {
        'info' {
            Write-Host "[$dat] $msg";
            break;
        }
        'ok' {
            Write-Host "[$dat] $msg" -ForegroundColor green;
            break;
        }
        'warning' {
            Write-Host "[$dat] $msg" -ForegroundColor yellow;
            $err += New-Object PSObject -Property @{Id = $counter; Date = $dat.ToUniversalTime().ToString($dFormat); Type=$what.ToLower(); Msg=$msg}
            break;
        }
        'error' {
            Write-Host "[$dat] $msg" -ForegroundColor Red;
            $err += New-Object PSObject -Property @{Id = $counter; Date = $dat.ToUniversalTime().ToString($dFormat); Type=$what.ToLower(); Msg=$msg}
            break;
        }
        'exception' {
            Write-Host "[$dat] $msg" -ForegroundColor Magenta;
            $err += New-Object PSObject -Property @{Id = $counter; Date = $dat.ToUniversalTime().ToString($dFormat); Type=$what.ToLower(); Msg=$msg}
            break;
        }
        'fatal' {
            Write-Host "[$dat] $msg Program will be stopped." -ForegroundColor Cyan;
            $err += New-Object PSObject -Property @{Id = $counter; Date = $dat.ToUniversalTime().ToString($dFormat); Type=$what.ToLower(); Msg=$msg}
            break;
        }
        'semi' {
            Write-Host "[$dat] $msg" -ForegroundColor gray;
            break;
        }
    }
    try {
        if($null -ne $logFile) {
            $parent = Split-Path $logFile
            if(!(test-Path $parent)) {md $parent}
            "[$dat] [$($what.ToUpper())] $msg" >> $logFile
        }
    }
    catch {Write-Host "Can't write to log. [$dat] $msg" -ForegroundColor Red;}
}

<#
.SYNOPSIS
    Function to replace all keys in $replaceThat to their values inside files with mask $fileMask in the path $basePath

.DESCRIPTION
    ...

.PARAMETER replaceThat
    ...

.PARAMETER basePath
    ...

.PARAMETER fileMask
    ...

.EXAMPLE
    ...
#>
function Invoke-It {
    [CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact="Low")]
    param(
        [parameter(Mandatory=$true, position=0)] [ValidateNotNullOrEmpty()] [hashtable] $replaceThat,
        [parameter(Mandatory=$true, position=1)] [ValidateNotNullOrEmpty()] [string] $basePath,
        [parameter(Mandatory=$true, position=2)] [ValidateNotNullOrEmpty()] [System.array] $fileMask
    )

    $findWhat = @()
    $replaceThat.Keys | %{$findWhat += $_.ToString()}

    try {
        # Chack if files present
        if($findWhat.Count -gt 0) {
            # Chack if directory present
            if((Test-Path $basePath -PathType Container) -eq $true) {
                $suitableFiles = (dir $basePath -Recurse -Include $fileMask | Select-String -Pattern $findWhat -SimpleMatch -Encoding default | group Path | select Name).Name  # -Encoding could be change in case locale mismatch
                # Check if suitable files found
                if($suitableFiles.Count -gt 0) {
                    Write-MyLog "Found [$($suitableFiles.Count)] files for processing"
                    $suitableFiles | %{
                        Write-MyLog "Starting with [$_]"
                        $output = @()
                        Get-Content $_ | %{
                            $tmp = $_;
                            for($i = 0; $i -lt $findWhat.Count; $i++) {
                                $tmp = $tmp.Replace($findWhat[$i], $replaceThat[$findWhat[$i]])
                            }
                            $output += $tmp
                        }                    
                        $output | Out-File -FilePath $_ -Encoding default -Force
                        Write-MyLog "Processing file [$_] is done" ok
                    }
                    Write-MyLog 'All files are processed'
                }
                else {Write-MyLog 'There are no targeted strings found in files' warning}
            }
            else {Write-MyLog "There is no such directory or it is not a directory [$basePath]" error}
        }
        else {Write-MyLog 'Ther is nothing to find'}
    }
    catch [Exception] {Write-MyLog "Something went wrong [$_]" exception} # Test Exception processing
}

# =============== Program starts =====================
$logFile = $null; # Skip logging to the disk

# This variable defined inside script because it is not so suitable to pass it from the command line
$replaceThat = @{
    'злая' = 'добрая';
    'кошка' = 'собака'; 
    'мяу' = 'гав';    
    'делает' = 'делает';
};

Invoke-It $replaceThat $basePath $fileMask



